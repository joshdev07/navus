<?php return array('dependencies' => array('react', 'wp-element'), 'version' => '827dc054b03edd4816dc');
