<?php return array('dependencies' => array(), 'version' => '09955cb3c59d625d6031');
