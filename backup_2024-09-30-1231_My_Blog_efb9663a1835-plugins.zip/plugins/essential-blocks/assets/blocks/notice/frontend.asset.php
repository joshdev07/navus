<?php return array('dependencies' => array(), 'version' => 'ec49e4cc527c77330952');
