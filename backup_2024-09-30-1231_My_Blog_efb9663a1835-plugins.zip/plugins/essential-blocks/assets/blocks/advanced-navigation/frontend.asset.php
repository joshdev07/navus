<?php return array('dependencies' => array(), 'version' => '4a4444b54520fdb52c2e');
