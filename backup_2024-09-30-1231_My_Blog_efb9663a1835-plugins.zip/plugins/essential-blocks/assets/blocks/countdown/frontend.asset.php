<?php return array('dependencies' => array('wp-dom-ready'), 'version' => '61af7baae9bd2e4a1cf7');
