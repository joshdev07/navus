<?php return array('dependencies' => array(), 'version' => 'ad3e0e7315392841164f');
