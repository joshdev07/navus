<?php return array('dependencies' => array(), 'version' => '645596ed096532ab4f1f');
