<?php return array('dependencies' => array(), 'version' => 'ac95781201d9d2e88caf');
