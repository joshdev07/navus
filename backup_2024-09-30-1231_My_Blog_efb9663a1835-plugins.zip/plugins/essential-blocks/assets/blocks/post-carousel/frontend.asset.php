<?php return array('dependencies' => array('wp-api-fetch'), 'version' => 'f4c85c3102e436aebc20');
