<?php return array('dependencies' => array('react', 'wp-element'), 'version' => '9a31e893a2d9d8ac48f8');
