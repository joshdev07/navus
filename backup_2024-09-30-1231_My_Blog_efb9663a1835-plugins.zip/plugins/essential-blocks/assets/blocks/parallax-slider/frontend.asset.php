<?php return array('dependencies' => array(), 'version' => 'bb963b6f408c13fdcfaa');
