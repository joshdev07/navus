<?php return array('dependencies' => array(), 'version' => '45e73ffbd56a6b9d0781');
