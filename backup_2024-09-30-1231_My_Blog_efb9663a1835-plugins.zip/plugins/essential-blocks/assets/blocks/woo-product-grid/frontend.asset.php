<?php return array('dependencies' => array('wp-api-fetch'), 'version' => 'bf99a8f9531fdea8c3aa');
