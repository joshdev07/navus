<?php return array('dependencies' => array(), 'version' => '004ad720317e6670e0ac');
