<?php return array('dependencies' => array(), 'version' => 'daef2f94474a53d4a23e');
