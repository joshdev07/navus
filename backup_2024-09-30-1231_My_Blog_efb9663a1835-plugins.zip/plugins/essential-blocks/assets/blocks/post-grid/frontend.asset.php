<?php return array('dependencies' => array('wp-api-fetch'), 'version' => '29fa28929ecd83685df8');
