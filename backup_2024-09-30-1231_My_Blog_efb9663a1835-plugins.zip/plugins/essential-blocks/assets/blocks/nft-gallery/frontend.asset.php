<?php return array('dependencies' => array('lodash', 'react', 'wp-element'), 'version' => '62498c0bf4970177f5ff');
