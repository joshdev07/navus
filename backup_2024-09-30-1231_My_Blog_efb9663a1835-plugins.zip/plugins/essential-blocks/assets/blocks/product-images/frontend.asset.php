<?php return array('dependencies' => array('wp-dom-ready'), 'version' => '8c434349b6f375b9568d');
