<?php return array('dependencies' => array('react', 'wp-element'), 'version' => '138f85bb8a556e5ac828');
