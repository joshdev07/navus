<?php return array('dependencies' => array(), 'version' => '6db72b1be59adae253ef');
