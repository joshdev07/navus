<?php return array('dependencies' => array(), 'version' => '97272c1ec7e2a226d604');
