<?php return array('dependencies' => array(), 'version' => '49f333bf7684112fb394');
