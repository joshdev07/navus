<?php return array('dependencies' => array(), 'version' => '4edac9c038686d9e6895');
