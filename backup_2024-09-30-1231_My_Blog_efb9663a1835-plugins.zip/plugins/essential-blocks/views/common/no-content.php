<p>
    <?php
        echo esc_html( $content );
    ?>
</p>
