<div class="eb-instagram-meta">
	<span class="dashicons dashicons-clock"></span>
	<span class="eb-instagram-date">
		<?php esc_html( gmdate( 'd M Y', strtotime( $timestamp ) ) ); ?>
	</span>
</div>
