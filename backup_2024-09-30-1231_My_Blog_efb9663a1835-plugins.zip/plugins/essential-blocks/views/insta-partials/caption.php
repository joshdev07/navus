<?php
    /**
     * @var string $caption
     */
?>
<div class="eb-instagram-caption">
	<p>
        <?php
            echo esc_html( $caption );
        ?>
    </p>
</div>
