<p class="eb-woo-product-price">
	<?php echo wp_kses_post( $product->get_price_html() ); ?>
</p>
