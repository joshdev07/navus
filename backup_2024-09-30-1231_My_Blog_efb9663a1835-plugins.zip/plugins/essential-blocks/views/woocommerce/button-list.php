<div class="eb-woo-product-button-list">
	<?php woocommerce_template_loop_add_to_cart(); ?>
</div>
