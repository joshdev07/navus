<p class="eb-woo-product-details">
	<?php echo wp_trim_words( wp_kses_post(get_the_content()), $productDescLength ); ?>
</p>
