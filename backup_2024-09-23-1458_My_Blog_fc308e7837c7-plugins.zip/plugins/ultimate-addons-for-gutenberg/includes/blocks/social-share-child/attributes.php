<?php
/**
 * Attributes File.
 *
 * @since 2.0.0
 *
 * @package uagb
 */

return array(
	'type'                => 'facebook',
	'image_icon'          => 'icon',
	'icon'                => 'facebook',
	'image'               => '',
	'icon_color'          => '',
	'icon_hover_color'    => '',
	'icon_bg_color'       => '',
	'icon_bg_hover_color' => '',
);
