<?php return array('dependencies' => array(), 'version' => 'cc4d3f0cfd506cfac7a4');
