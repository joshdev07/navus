<?php return array('dependencies' => array('wp-data', 'wp-polyfill'), 'version' => 'b816563d374d10cec1a7');
